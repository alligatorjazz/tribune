---
template: "default"
---
Her was a movie. There were many goings on that happened over the course of the movie. Many things were said, events happened, and characters were there. Throughout the movie, one character would say something, and then another character would reply with something. There were also times where characters were NOT talking, and there was music or other things happening on screen. At the end, the credits rolled and we got to see who made the movie. 

1 star bad movie